python-monascaclient Style Commandments
===============================================

Read the OpenStack Style Commandments http://docs.openstack.org/developer/hacking/